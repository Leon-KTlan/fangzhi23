import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigInteger;
import java.util.Random;

public class RSACryptoApp extends JFrame {
    private JTextField inputField;
    private JTextArea outputArea; // 改为JTextArea以支持多行和滚动条
    private JButton encryptButton;
    private JButton decryptButton;
    private JButton generateKeysButton;
    private JButton customKeysButton;
    private JTextArea publicKeyArea;
    private JTextArea privateKeyArea;

    private BigInteger n; // 模数
    private BigInteger e; // 公钥指数
    private BigInteger d; // 私钥指数
    private final int BIT_LENGTH = 1024; // 默认密钥长度

    public RSACryptoApp() {
        setTitle("RSA数字加密解密器(支持自定义参数)");
        setSize(700, 500); // 增加窗口高度以适应更大的显示区域
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        initComponents();
        generateKeys();
    }

    private void initComponents() {
        JPanel inputPanel = new JPanel(new FlowLayout());
        inputPanel.add(new JLabel("输入数字:"));
        inputField = new JTextField(15);
        inputPanel.add(inputField);

        JPanel buttonPanel = new JPanel(new FlowLayout());
        encryptButton = new JButton("加密");
        decryptButton = new JButton("解密");
        generateKeysButton = new JButton("自动生成密钥");
        customKeysButton = new JButton("自定义密钥参数");

        encryptButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                encrypt();
            }
        });

        decryptButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                decrypt();
            }
        });

        generateKeysButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                generateKeys();
            }
        });

        customKeysButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                showCustomKeyDialog();
            }
        });

        buttonPanel.add(encryptButton);
        buttonPanel.add(decryptButton);
        buttonPanel.add(generateKeysButton);
        buttonPanel.add(customKeysButton);

        JPanel outputPanel = new JPanel(new BorderLayout());
        outputPanel.add(new JLabel("结果:"), BorderLayout.NORTH);
        outputArea = new JTextArea(5, 40); // 多行文本区域
        outputArea.setEditable(false);
        outputArea.setLineWrap(true); // 自动换行
        outputArea.setWrapStyleWord(true); // 按单词换行
        JScrollPane scrollPane = new JScrollPane(outputArea); // 添加滚动条
        outputPanel.add(scrollPane, BorderLayout.CENTER);

        JPanel keyPanel = new JPanel(new GridLayout(2, 1));
        JPanel publicKeyPanel = new JPanel(new BorderLayout());
        publicKeyPanel.add(new JLabel("公钥 (n, e):"), BorderLayout.NORTH);
        publicKeyArea = new JTextArea(3, 50);
        publicKeyArea.setEditable(false);
        publicKeyArea.setLineWrap(true);
        publicKeyArea.setWrapStyleWord(true);
        publicKeyPanel.add(new JScrollPane(publicKeyArea), BorderLayout.CENTER);

        JPanel privateKeyPanel = new JPanel(new BorderLayout());
        privateKeyPanel.add(new JLabel("私钥 (n, d):"), BorderLayout.NORTH);
        privateKeyArea = new JTextArea(3, 50);
        privateKeyArea.setEditable(false);
        privateKeyArea.setLineWrap(true);
        privateKeyArea.setWrapStyleWord(true);
        privateKeyPanel.add(new JScrollPane(privateKeyArea), BorderLayout.CENTER);

        keyPanel.add(publicKeyPanel);
        keyPanel.add(privateKeyPanel);

        add(inputPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.CENTER);
        add(outputPanel, BorderLayout.SOUTH);
        add(keyPanel, BorderLayout.EAST);
    }

    private void showCustomKeyDialog() {
        JDialog dialog = new JDialog(this, "自定义RSA参数", true);
        dialog.setLayout(new GridLayout(0, 2, 10, 10));
        dialog.setSize(500, 300);

        JTextField pField = new JTextField();
        JTextField qField = new JTextField();
        JTextField eField = new JTextField("65537");

        dialog.add(new JLabel("素数 p:"));
        dialog.add(pField);
        dialog.add(new JLabel("素数 q:"));
        dialog.add(qField);
        dialog.add(new JLabel("公钥指数 e:"));
        dialog.add(eField);

        JButton confirmButton = new JButton("确认");
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                try {
                    BigInteger p = new BigInteger(pField.getText());
                    BigInteger q = new BigInteger(qField.getText());
                    BigInteger newE = new BigInteger(eField.getText());

                    if (!p.isProbablePrime(100) || !q.isProbablePrime(100)) {
                        JOptionPane.showMessageDialog(dialog, "p和q必须是素数", "错误", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    if (p.equals(q)) {
                        JOptionPane.showMessageDialog(dialog, "p和q不能相同", "错误", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    n = p.multiply(q);
                    BigInteger phi = p.subtract(BigInteger.ONE).multiply(q.subtract(BigInteger.ONE));

                    if (newE.compareTo(BigInteger.ONE) <= 0 || newE.compareTo(phi) >= 0) {
                        JOptionPane.showMessageDialog(dialog, "e必须满足1 < e < φ(n)", "错误", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    if (!newE.gcd(phi).equals(BigInteger.ONE)) {
                        JOptionPane.showMessageDialog(dialog, "e必须与φ(n)互质", "错误", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    e = newE;
                    d = e.modInverse(phi);

                    publicKeyArea.setText("n: " + n.toString() + "\ne: " + e.toString());
                    privateKeyArea.setText("n: " + n.toString() + "\nd: " + d.toString());

                    dialog.dispose();
                    JOptionPane.showMessageDialog(RSACryptoApp.this,
                            "已使用自定义参数生成RSA密钥对", "成功", JOptionPane.INFORMATION_MESSAGE);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(dialog, "请输入有效的数字", "错误", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        JButton cancelButton = new JButton("取消");
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                dialog.dispose();
            }
        });

        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.add(confirmButton);
        buttonPanel.add(cancelButton);

        dialog.add(new JLabel());
        dialog.add(buttonPanel);

        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private void generateKeys() {
        Random rnd = new Random();
        // 生成两个大素数
        BigInteger p = BigInteger.probablePrime(BIT_LENGTH, rnd);
        BigInteger q = BigInteger.probablePrime(BIT_LENGTH, rnd);

        // 确保p和q不同
        while (p.equals(q)) {
            q = BigInteger.probablePrime(BIT_LENGTH, rnd);
        }

        // 计算模数n
        n = p.multiply(q);

        // 计算欧拉函数φ(n)
        BigInteger phi = p.subtract(BigInteger.ONE).multiply(q.subtract(BigInteger.ONE));

        // 选择公钥指数e(默认用65537)
        e = new BigInteger("65537");

        // 确保e与φ(n)互质
        while (phi.gcd(e).compareTo(BigInteger.ONE) > 0 && e.compareTo(phi) < 0) {
            e = e.add(BigInteger.ONE);
        }

        // 计算私钥指数d
        d = e.modInverse(phi);

        //显示生成的参数
        publicKeyArea.setText("n: " + n.toString() + "\ne: " + e.toString());
        privateKeyArea.setText("n: " + n.toString() + "\nd: " + d.toString());

        JOptionPane.showMessageDialog(this, "已自动生成RSA密钥对", "成功", JOptionPane.INFORMATION_MESSAGE);
    }

    private void encrypt() {
        try {
            BigInteger input = new BigInteger(inputField.getText());
            // 验证输入范围
            if (input.compareTo(n) >= 0) {
                JOptionPane.showMessageDialog(this, "输入数字必须小于n=" + n, "错误", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // 执行加密计算
            BigInteger encrypted = input.modPow(e, n);
            outputArea.setText(encrypted.toString()); // 改为设置JTextArea的文本
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "请输入有效的数字", "错误", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void decrypt() {
        try {

            BigInteger input = new BigInteger(inputField.getText());
            // 执行解密计算
            BigInteger decrypted = input.modPow(d, n);
            outputArea.setText(decrypted.toString()); // 改为设置JTextArea的文本
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "请输入有效的数字", "错误", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new RSACryptoApp().setVisible(true);
            }
        });
    }
}